import sys

from matplotlib import style
import xlwt



analysis_all = 0
analysis_record = []
test_record = []
common_rule = {
    'full_time' : '45 -> ',
    'if_execution' : '46 -> ',
    'rfifo_time' : '47 -> ',
    'without_rfifo' : '48 -> ',
    'other_exe' : '23 -> ',
    'load_cnt' : '10 -> ',
    'load_miss_cnt' : '9 -> ',
    'store_cnt' : '59 -> ',
    'store_hit_cnt' : '60 -> ',
    'store_overlap' : '61 -> ',
    'rule_map_hit' : '11 -> ',
    'rule_map_cnt' : '12 -> ',
    'rule_set_hit' : '13 -> ',
    'rule_set_cnt' : '14 -> ',
    'total_req' : '16 -> ',
    'check_cnt' : '17 -> ',
    'check_overcap' : '30 -> ',
    'check_cycle' : '8 -> ',
    'L1_rlb_hit' : '18 -> ',
    'L2_rlb_hit' : '19 -> ',
    'mon_load' : '6 -> ',
    'mon_store' : '7 -> ',
    'mon_check' : '8 -> '
}

dfi_rule = {
    'store_req' : '24 -> ',
    'load_req' : '25 -> ',
    'lib_req' : '26 -> ',
    'store_time' : '27 -> ',
    'load_time' : '28 -> ',
    'lib_time' : '29 -> ',
    'rdt_updata' : '7 -> ',
    'rdt_read' : '6 -> ',
    'rds_read' : '8 -> ',
    'hdfi_load_time' : '62 -> ',
}

cfi_rule = {
    'jalr_req' : '31 -> ',
    'call_req' : '32 -> ',
    'ret_req' : '33 -> ',
    'jalr_time' : '34 -> ',
    'call_time' : '35 -> ',
    'ret_time' : '36 -> ',
    'rds_read' : '8 -> ',
}

st_rule = {
    'pop_req' : '37 -> ',
    'push_pop' : '38 -> ',
    'pop_time' : '39 -> ',
    'push_time' : '40 -> ',
}

whlist_rule = {
    'load_req' : '41 -> ',
    'load_time' : '42 -> ',
    'lib_req' : '43 -> ',
    'lib_time' : '44 -> '
}

dfi_latency =   {'dfi_latency' : '49 -> ',}
hdfi_latency =   {'hdfi_latency' : '50 -> ',}
cfi_latency =   {'cfi_latency' : '51 -> ','cfi_ret_latency' : '52 -> '}
st_latency =   {'st_latency' : '53 -> ',}
wh_latency =   {'whlist_latency' : '54 -> ',}

def text_analysis(text, spec, type, logname, aapend=0):
    begin = spec + '------------\n'
    begin_debug = 'DEBUG: rocc debug area begin\n'
    baseline = 0
    tmp = 0
    result = []
    result_name = []
    cnt = 0
    for i in range(len(text)):
        if begin == text[i]:
            tmp = i
            break
    print(tmp)
    tmp2 = 0
    for i in range(tmp,len(text)):
        if begin_debug == text[i]:
            tmp2 = i
            break
    tmp =tmp2
    print(tmp)
    find_num = len(type)
    for p in range(tmp,len(text)):
        if(text[p][:5] == '0 -> ' ):
            result.append( int(text[p][5:-1] ,16) / 50000000)
            result_name.append('Total_time')
            cnt += 1
        for i in type:       
            if(text[p][:6] == type[i] and len(type[i])==6):
                result.append(int(text[p][6:-1],16))
                result_name.append(i)
                cnt += 1
            elif(text[p][:5] == type[i] and len(type[i])==5):
                result.append(int(text[p][5:-1],16))
                result_name.append(i)
                cnt += 1
        if(cnt == find_num+1): break
    
    cnt = 0
    if aapend == 1:
        fo = open(logname,'a+')
    else:
        fo = open(logname,'w+')
    # print(len(result))
    # print(len(result_name))
    # fo.write('  ')
    # fo.write(spec)
    # fo.write('  \n')
    for res in result:
        fo.write(result_name[cnt])
        fo.write(' ')
        fo.write(str(res))
        fo.write('\n')
        cnt += 1
    fo.close() 
    return result 

def excle_w(sheel_time,test_name):    
    
    xls = xlwt.Workbook()  
    # 创建一个sheet, 并对sheet命名
    sheet1 = xls.add_sheet(sheel_time)
    # 设置字体格式
    Font0 = xlwt.Font()
    Font0.name = "Times New Roman"
    # 设置单元格底色
    style1 = xlwt.easyxf('pattern: pattern solid, fore_colour bright_green;')
    # 使用指定背景色
    sheet1.write(0, 0, test_name, style1)

    ct = 0
    for test in analysis_record:
        ct += 1
        sheet1.write(0,ct,test,style1)

    for test in analysis_record:
        a = open(test+'_'+test_name,'r+')
        tmp = []
        tmp = a.readlines()
        time_tmp = ''
        cnt = 0
        del_c = []
        for tt in tmp:
            if tt[:5] == 'Total':
                time_tmp = tt
                del_c.append(cnt)
            cnt += 1
        tmp2 = []
        tmp2.append(time_tmp)
        del_cnt = 0
        for i in del_c:
            del tmp[i-del_cnt]
            del_cnt += 1
        for i in tmp:
            tmp2.append(i)
        a.close()
        a = open(test+'_'+test_name,'w')
        for i in tmp2:
            a.write(i)
        

        a.close()
    
    tmp = []
    tmp_s = []
    ct = 0
    sheet1.write(1,0,'Baseline_time',style1)
    for test in analysis_record:
        a = open(test+'_orilog','r+')
        tmp = a.readlines()
        for tt in tmp:
            tmp_s = tt.split()
            ct += 1
            sheet1.write(1,ct,tmp_s[1],style1)
    


    ct = 0
    cline = 1
    if_enrty = 0
    tmp = []
    tmp_s = []
    for test in analysis_record:
        a = open(test+'_'+test_name,'r+')
        tmp = a.readlines()
        ct += 1
        cline = 1
        for tt in tmp:
            tmp_s = tt.split()
            cline += 1
            if if_enrty==0:
                sheet1.write(cline,0,tmp_s[0],style1)
            sheet1.write(cline,ct,tmp_s[1],style1)
        if if_enrty==0:
            if_enrty = 1
        a.close()
    xls.save('result_'+test_name+'.xls') 

p =[]
for i in range(1,len(sys.argv)): 
    p.append(i)

for i in p:
    if sys.argv[i] == 'all':
        analysis_all = 1
    if sys.argv[i] == '-dfi':       
        test_record.append('dfilog')
    if sys.argv[i] == '-cfi':       
        test_record.append('cfi')
    if sys.argv[i] == '-stack':       
        test_record.append('sstack')
    if sys.argv[i] == '-whlist':       
        test_record.append('whlist')
    if sys.argv[i] == '-hdfi':       
        test_record.append('hdfilog')
    if sys.argv[i] == '-allpolicy':       
        test_record = ['orilog','dfilog','hdfilog','cfi','sstack','whlist']
    if sys.argv[i] == '401':       
        analysis_record.append(sys.argv[i])
    if sys.argv[i] == '429':       
        analysis_record.append(sys.argv[i])
    if sys.argv[i] == '433':       
        analysis_record.append(sys.argv[i])
    if sys.argv[i] == '445':       
        analysis_record.append(sys.argv[i])
    if sys.argv[i] == '458':       
        analysis_record.append(sys.argv[i])
    if sys.argv[i] == '462':       
        analysis_record.append(sys.argv[i])
    if sys.argv[i] == '470':       
        analysis_record.append(sys.argv[i])
    if sys.argv[i] == '473':       
        analysis_record.append(sys.argv[i])
    if sys.argv[i] == '456':       
        analysis_record.append(sys.argv[i])

ft = open('C:/Users/lenovo/Desktop/项目资料/动态安全/code_space/result_handle/log_oneFIFO/logOoO-whlist','r')
text_lines = ft.readlines()

if analysis_all == 1:
    analysis_record = ['401','429','433','445','456','458','462','470','473']

for test in analysis_record:
    text_analysis(text_lines,test+'',{},test+'_orilog',0)
for test in analysis_record:
    text_analysis(text_lines,test+' dfi',dfi_rule,test+'_dfilog',0)
for test in analysis_record:
    text_analysis(text_lines,test+' dfi',common_rule,test+'_dfilog',1)
for test in analysis_record:
    text_analysis(text_lines,test+' dfi',dfi_latency,test+'_dfilog',1)
for test in analysis_record:
    text_analysis(text_lines,test+' hdfi',dfi_rule,test+'_hdfilog',0)
for test in analysis_record:
    text_analysis(text_lines,test+' hdfi',common_rule,test+'_hdfilog',1)
for test in analysis_record:
    text_analysis(text_lines,test+' hdfi',hdfi_latency,test+'_hdfilog',1)
for test in analysis_record:
    text_analysis(text_lines,test+' cfi',cfi_rule,test+'_cfi',0)
for test in analysis_record:
    text_analysis(text_lines,test+' cfi',common_rule,test+'_cfi',1)
for test in analysis_record:
    text_analysis(text_lines,test+' cfi',cfi_latency,test+'_cfi',1)
for test in analysis_record:
    text_analysis(text_lines,test+' sstack',st_rule,test+'_sstack',0)
for test in analysis_record:
    text_analysis(text_lines,test+' sstack',common_rule,test+'_sstack',1)
for test in analysis_record:
    text_analysis(text_lines,test+' sstack',st_latency,test+'_sstack',1)
for test in analysis_record:
    text_analysis(text_lines,test+' whlist',whlist_rule,test+'_whlist',0)
for test in analysis_record:
    text_analysis(text_lines,test+' whlist',common_rule,test+'_whlist',1)
for test in analysis_record:
    text_analysis(text_lines,test+' whlist',wh_latency,test+'_whlist',1)


for test in test_record:
    excle_w(test,test)