import sys

reg_alarm = '22 -> '
reg_alarm_0 = '65 -> '
reg_alarm_1 = '66 -> '
check_alarm = '56 -> '
check_alarm_0 = '63 -> '
check_alarm_1 = '64 -> '
total_num = 6

log_name_prefix = 'log_ripe_'
debug_begin = 'Begin test...\n'
dfi_func_id = [0x7c2,0x7c1,0x7c3]
PC_ls = 0x16762
PC_up = 0x18da2
case_num = 157

def read_log(logname):
    f=open(logname)
    text = f.readlines()
    result = [] # 0:reg alarm   1:check alarm
    result_alarm = [] # 0 1: check_alarm_0/1  2,3: reg_alarm_0/1
    begin = 0 
    cnt = 0
    for i in range(len(text)):
        if(text[i] == debug_begin):
            begin = i
            break
    for i in range(begin,len(text)):
        if(text[i][:6] == reg_alarm):
            result.append( int(text[i][6:-1],16))
            cnt += 1
        if(text[i][:6] == check_alarm):
            result.append(int(text[i][6:-1],16))
            cnt += 1
        if(text[i][:6] == check_alarm_0):
            result_alarm.append(int(text[i][6:-1],16))
            cnt += 1
        if(text[i][:6] == check_alarm_1):
            result_alarm.append(int(text[i][6:-1],16))
            cnt += 1
        if(text[i][:6] == reg_alarm_0):
            result_alarm.append(int(text[i][6:-1],16))
            cnt += 1
        if(text[i][:6] == reg_alarm_1):
            result_alarm.append(int(text[i][6:-1],16))
            cnt += 1
        if(cnt == 6):
            break
    f.close()
    return (result,result_alarm)    

def analysis_alarm_count(count, result):
    begin_count = [0,0]
    result_cnt = []
    for i in range(count):
        tmp0 = result[i][0]-begin_count[0]
        tmp1 = result[i][1]-begin_count[1]
        result_cnt.append([tmp0,tmp1])
        begin_count = [result[i][0],result[i][1]]
    return result_cnt

def dfi_policy(result, result_alarm):
    result_string = []
    for i in range(len(result)):
        alarm_ok = (((result_alarm[i][0]) >> 16) in dfi_func_id) or (((result_alarm[i][1]) >> 16) in dfi_func_id)
        # print(result_alarm[i][0] >> 16)
        # print((result_alarm[i][0] >> 16) in dfi_func_id)
        if (result[i][0] > 0) or ((result[i][1]>0) and alarm_ok ):
            result_string.append('OK')
        else:
            result_string.append('FALSE')
    return result_string
             
def cfi_policy(result, result_alarm):
    result_string = []
    for i in range(len(result)):
        alarm_ok = ((result_alarm[i][2] & 0xffffffff) == PC_up) and (result_alarm[i][2] & 0xffffffff > PC_ls)
        if ((result[i][0] > 0)  and alarm_ok ) or (result[i][1] > 0):
            result_string.append('OK')
        else:
            result_string.append('FALSE')
    return result_string

def stack_policy(result, result_alarm):
    result_string = []
    for i in range(len(result)):
        alarm_ok = ((result_alarm[i][2] & 0xffffffff) == PC_up) and (result_alarm[i][2] & 0xffffffff > PC_ls)
        if ((result[i][0] > 0) and alarm_ok) :
            result_string.append('OK')
        else:
            result_string.append('FALSE')
    return result_string

def hdfi_policy(result, result_alarm):
    result_string = []
    for i in range(len(result)):
        if result[i][0] > 0:
            result_string.append('OK')
        else:
            result_string.append('FALSE')
    return result_string

all_result = []
all_result_alarm = []
for i in range(case_num):
    log_name = log_name_prefix + str(i)
    tmp = read_log(log_name)
    all_result.append(tmp[0])
    all_result_alarm.append(tmp[1])

#print(all_result)
case_result = analysis_alarm_count(case_num,all_result)
# print(case_result)

p =[]
for i in range(1,len(sys.argv)): 
    p.append(i)

for i in p:
    if sys.argv[i] == '-stack':
        case = 'stack'
    if sys.argv[i] == '-dfi':       
        case = 'dfi'
    if sys.argv[i] == '-hdfi':       
        case = 'hdfi'
    if sys.argv[i] == '-cfi':       
        case = 'cfi'

if case == 'dfi':
    res_print = dfi_policy(case_result,all_result_alarm)
    print("DFI RIPE------->>>>>")
    ok_cnt = 0
    for i in range(case_num):
        print(str(i) + '--->' + res_print[i])
        if(res_print[i]=='OK'):
            ok_cnt+=1
    print("DFI OK total --->>>>>>"+str(ok_cnt))

if case == 'hdfi':
    res_print = hdfi_policy(case_result,all_result_alarm)
    print("HDFI RIPE------->>>>>")
    ok_cnt = 0
    for i in range(case_num):
        print(str(i) + '--->' + res_print[i])
        if(res_print[i]=='OK'):
            ok_cnt+=1
    print("DFI OK total --->>>>>>"+str(ok_cnt))
if case == 'cfi':
    print("CFI RIPE------->>>>>")
    res_print = cfi_policy(case_result,all_result_alarm)
    ok_cnt = 0
    for i in range(case_num):
        print(str(i) + '--->' + res_print[i])
        if(res_print[i]=='OK'):
            ok_cnt+=1
    print("DFI OK total --->>>>>>"+str(ok_cnt))
if case == 'stack':
    print("Shadow Stack RIPE------->>>>>")
    res_print = stack_policy(case_result,all_result_alarm)
    ok_cnt = 0
    for i in range(case_num):
        print(str(i) + '--->' + res_print[i])
        if(res_print[i]=='OK'):
            ok_cnt+=1
    print("Shadow stack OK total --->>>>>>"+str(ok_cnt))