import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pylab import mpl
from matplotlib.ticker import MultipleLocator
import sys
import numpy as np
mpl.rcParams["font.family"] =  "Times New Roman" 
mpl.rcParams["mathtext.fontset"] = 'cm' 
mpl.rcParams["font.size"] = 10.5
rgbcolor=[(123/255, 189/255, 205/255),
(103/255, 169/255, 185/255),
(83/255, 149/255, 165/255),
(73/255, 129/255, 145/255),
(63/255, 109/255, 125/255),
(53/255, 89/255, 105/255),
(43/255, 79/255, 85/255),
(33/255, 59/255, 65/255),
]


rgb_limit0 = ['silver','gray']
rgb_limit1 = ['skyblue','steelblue']
rgb_limit2 = ['Khaki','Gold']
sur_param3 = ['*','-','/']
line_param3 = ['*','o']

# rgbcolor1=['white','whitesmoke','lightgray','darkgray','grey',]

#read data
# data = pd.read_excel("res.xlsx", sheet_name='Sheet1')
# x = data.iloc[:11,0]
# y1 = data.iloc[:11,10] *100
# y2 = data.iloc[:11,11] *100
test_case_name = ['Shdow Stack','White-List','CFI', 'LW-DIFT', 'DFI']
test_case = ['result_sstack','result_whlist','result_cfi', 'result_hdfilog', 'result_dfilog']
opt_case = ['noopt', 'c8k', 'c1k', 'rlb64', 'rlb16', 'OoO', 'paral','all']
opt_case_name = ['Basic', 'MCache_1KB', 'MCache_8KB', 'RLB_256B', 'RLB_1KB', 'OoO', 'ParlCmp','ProMiSE']
res_path_prefix = 'C:/Users/lenovo/Desktop/项目资料/动态安全/code_space/result_handle/log_oneFIFO'
opt_num = len(test_case)

data = [[],[],[],[],[],[],[],[]]
for i in range(0,len(opt_case)):
    for j in range(0,len(test_case)):
        res_path = './' + opt_case[i] + '/' + test_case[j] + '.xls'
        data[i].append(pd.read_excel(res_path,sheet_name = test_case[j][7:]))


# print(data[0])

def align_xaxis(ax1, v1, ax2, v2):
    """adjust ax2 xlimit so that v2 in ax2 is aligned to v1 in ax1"""
    x1, _ = ax1.transData.transform((v1, 0))
    x2, _ = ax2.transData.transform((v2, 0))
    inv = ax2.transData.inverted()
    dx, _ = inv.transform((0, 0)) - inv.transform((x1-x2, 0))
    minx, maxx = ax2.get_xlim()
    ax2.set_xlim(minx+dx, maxx+dx)

def average(loc_name):
    tmp = []
    for i in range(0,len(opt_case)):
        for j in range(0,len(test_case)):
            # print(data[i][j])
            tmpp = data[i][j].loc[:,test_case[j][7:]]
            # print(data[i][j])
            cnt = 0
            for aa in tmpp:
                if aa == loc_name:
                    break
                else:
                    cnt += 1
            #print(cnt)
            # print(data[i][j].iloc[cnt][10])
            tmp.append(data[i][j].iloc[cnt][10])
    return tmp

def get_line(loc_name):
    tmp = []
    for i in range(0,len(opt_case)):
        for j in range(0,len(test_case)):
            tmpp = data[i][j].loc[:,test_case[j][7:]]
            cnt = 0
            for aa in tmpp:
                if aa == loc_name:
                    break
                else:
                    cnt += 1
            # print(cnt)
            # print(data[i][j].iloc[len(data[i][j])-2])
            tmp.append(data[i][j].iloc[cnt])
            # print(i)
            # print(j)
            # print(data[i][j].iloc[cnt])
    return tmp

def get_line_de(loc_name,i,j):
    tmp = []
    tmpp = data[i][j].loc[:,test_case[j][7:]]
    cnt = 0
    for aa in tmpp:
        if aa == loc_name:
            break
        else:
            cnt += 1
    tmp.append(data[i][j].iloc[cnt])
    return tmp
def draw_latency():
    x_widht = range(0,len(test_case))
    x_new = range(0,len(opt_case))

    fig = plt.figure(figsize=(5,1.3))  # 创建画布
    ax = plt.gca()

    y_noopt = average('latency')[0:opt_num]
    y_c8k = average('latency')[opt_num: 2*opt_num]
    y_c1k = average('latency')[2*opt_num:3*opt_num]
    y_rlb64 = average('latency')[3*opt_num:4*opt_num]
    y_rlb16 = average('latency')[4*opt_num:5*opt_num]
    y_OoO = average('latency')[5*opt_num:6*opt_num]
    y_paral = average('latency')[6*opt_num:7*opt_num]
    y_all = average('latency')[7*opt_num:8*opt_num]

    print(average('latency'))

    print(y_noopt)
    print(y_c8k)
    print(y_c1k)
    print(y_rlb64)
    print(y_rlb16)
    print(y_OoO)
    print(y_all)

    y_sstack = [y_noopt[0],y_c1k[0],y_c8k[0],y_rlb16[0],y_rlb64[0],y_OoO[0],y_paral[0],y_all[0]]
    y_whlist = [y_noopt[1],y_c1k[1],y_c8k[1],y_rlb16[1],y_rlb64[1],y_OoO[1],y_paral[1],y_all[1]]
    y_cfi = [y_noopt[2],y_c1k[2],y_c8k[2],y_rlb16[2],y_rlb64[2],y_OoO[2],y_paral[2],y_all[2]]
    y_hdfi = [y_noopt[3],y_c1k[3],y_c8k[3],y_rlb16[3],y_rlb64[3],y_OoO[3],y_paral[3],y_all[3]]
    y_dfi = [y_noopt[4],y_c1k[4],y_c8k[4],y_rlb16[4],y_rlb64[4],y_OoO[4],y_paral[4],y_all[4]]

    x_0 = [i-0.35 for i in x_widht]
    x_1 = [i-0.25 for i in x_widht]
    x_2 = [i-0.15 for i in x_widht]
    x_3 = [i-0.05 for i in x_widht]
    x_4 = [i+0.05 for i in x_widht]
    x_5 = [i+0.15 for i in x_widht]
    x_6 = [i+0.25 for i in x_widht]
    x_7 = [i+0.35 for i in x_widht]


    ax.plot(x_new,y_sstack,color = 'black',marker='s',markersize=6,markerfacecolor='white',linestyle='-')
    ax.plot(x_new,y_whlist,color = 'black',marker='D',markersize=5,linestyle='--')
    ax.plot(x_new,y_cfi,color = 'black',marker='x',markersize=4, linestyle='-')
    ax.plot(x_new,y_hdfi,color = 'black',marker='^',markersize=6,linestyle='-')
    ax.plot(x_new,y_dfi,color = 'black',marker='o',markersize=4,linestyle='-')

    ax.set_xlim(-0.5,len(x_new)-0.5)
    ax.set_ylim(0,220) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    # plt.xticks(range(0,len(test_case)),test_case_name,rotation=30)
    plt.xticks(range(0,len(x_new)),opt_case_name,rotation=25)
    plt.grid(linestyle = ":")
    ax.set_ylabel('Average Detection \n Latency (cycle)')
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    # ax.legend(['Basic','Dedicated Cache 1KB','Dedicated Cache 8KB','RLB 256B','RLB 1KB','OoO','Parallel Comparator','All'])
    ax.legend(test_case_name,ncol=5,loc='center',fontsize = 8.5,bbox_to_anchor=(0.5,1.13))
    plt.savefig('latency.pdf',dpi=300, bbox_inches='tight')
    plt.show()

def draw_overhead():
    x_widht = range(0,10)

    fig = plt.figure(figsize=(10,1.2))  # 创建画布
    ax = plt.gca()
    ax2 = ax.twinx()


    y_ss = (get_line('overhead')[7*5][1:11]).tolist()
    y_wh = (get_line('overhead')[7*5+1][1:11]).tolist()
    y_cfi = (get_line('overhead')[7*5+2][1:11]).tolist()
    y_hdfi = (get_line('overhead')[7*5+3][1:11]).tolist()
    y_dfi = (get_line('overhead')[7*5+4][1:11]).tolist()

    y_ss_cfi_req = get_line_de('req_feq',7,2)[0][1:11]
    y_ss_req = get_line_de('req_feq',7,0)[0][1:11]
    y_dfi_req = get_line_de('req_feq',7,4)[0][1:11]
    y_whlist_req = get_line_de('load_feq',7,4)[0][1:11]


    y_ss = [i*100 for i in y_ss]
    y_wh = [i*100 for i in y_wh]
    y_cfi = [i*100 for i in y_cfi]
    y_hdfi = [i*100 for i in y_hdfi]
    y_dfi = [i*100 for i in y_dfi]

    y_ss_cfi_req = [i*1000 for i in y_ss_cfi_req]
    y_ss_req = [i*1000 for i in y_ss_req]
    y_dfi_req = [i*1000 for i in y_dfi_req]
    y_whlist_req = [i*1000 for i in y_whlist_req]

    print(y_ss)
    print(y_wh)
    print(y_cfi)
    print(y_hdfi)
    print(y_dfi)

    print(y_whlist_req)
    print(y_dfi_req)


    x_0 = [i-0.3 for i in x_widht]
    x_1 = [i-0.15 for i in x_widht]
    x_2 = [i for i in x_widht]
    x_3 = [i+0.15 for i in x_widht]
    x_4 = [i+0.3 for i in x_widht]
    print(x_0)

    l0=ax.bar(x_0,y_ss,width=0.15,color = rgb_limit1[0],ec='k')
    l1=ax.bar(x_1,y_wh,width=0.15, color = 'white',ec=rgb_limit1[1])
    l2=ax.bar(x_2,y_cfi,width=0.15, color = rgb_limit1[1],ec='k')
    l3=ax.bar(x_3,y_hdfi,width=0.15,color = 'white',hatch='\\'*2,ec=rgb_limit1[1])
    l4=ax.bar(x_4,y_dfi,width=0.15,color = 'white',hatch='/'*4,ec=rgb_limit1[1])

    ax2.plot(x_3,y_ss_req, color='black',marker='s',markersize=5,markerfacecolor='white',linestyle='-.',lw=1.2)
    ax2.plot(x_3,y_ss_cfi_req, color='black',marker='x',markersize=5,markerfacecolor='white',linestyle='-',lw=1.2)
    ax2.plot(x_3,y_dfi_req, color='black',marker='o',markersize=5,linestyle='--',lw=1.2)
    ax2.plot(x_3,y_whlist_req, color='black',marker='^',markersize=5,markerfacecolor='white',linestyle=':',lw=1.2)

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(-5,55) 
    ax.tick_params(axis='x',labelsize=9.5)
    ax.tick_params(axis='y',colors=rgb_limit1[1],labelsize=9.5)
    ax2.tick_params(axis='y',labelsize=9.5)
    ax2.set_ylim(-10,110) 
    ax.yaxis.set_major_locator(MultipleLocator(20))
    ax2.yaxis.set_major_locator(MultipleLocator(20))


    ax.xaxis.set_major_locator(MultipleLocator(1))
    x_name = ['401.bzip2','429.mcf','433.milc','445.gobmk','456.hmmer','458.sjeng','462.libquantum','470.lbm','473.astar','Avg.']
    plt.xticks(range(0,10),x_name,rotation=0,fontsize=10)
    ax.grid(linestyle = ":")
    ax.set_ylabel('Performance Overhead (%)',color=rgb_limit1[1],fontsize=9.5)
    ax2.set_ylabel('Freq. (# / 1000 cycles)',fontsize=9.5)
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    ax.legend((l0,l1,l2,l3,l4),['Shadow Stack','White-List','CFI','LW-DIFT','DFI'],
            loc='upper right',bbox_to_anchor=(0.45,1.45),ncol=3,fontsize=7.7)
    ax2.legend(['Shadow Stack Req. (* 10)','CFI Req. (* 10)','LW-DIFT/DFI Req.','White-List Req.'],loc='upper left',bbox_to_anchor=(0.45,1.45),ncol=2,fontsize=7.7)

    plt.savefig('overhead.pdf',dpi=300, bbox_inches='tight')
    plt.show()

def draw_dfi(ax):
    x_widht = range(0,10)

    fig = plt.figure(figsize=(10,3))  # 创建画布
    # ax = plt.gca()
    ax2 = ax.twinx()


    y_rdt_r = get_line_de('rdt_read_pec',7,4)[0][1:11]
    y_rdt_w = get_line_de('rdt_write_pec',7,4)[0][1:11]
    y_rds_r = get_line_de('rds_pec',7,4)[0][1:11]
    y_rds_over = get_line_de('rds_overlap',7,4)[0][1:11]
    y_rdt_over = get_line_de('rdt_overlap',7,4)[0][1:11]
    y_other = get_line_de('other_pec',7,4)[0][1:11]
    y_over = get_line_de('overlap_pec',7,4)[0][1:11]

    y_load_pec = get_line_de('load_pec',7,4)[0][1:11]
    y_store_pec = get_line_de('store_pec',7,4)[0][1:11]
    y_lib_pec = get_line_de('lib_pec',7,4)[0][1:11]

    y_load_feq = get_line_de('load_feq',7,4)[0][1:11]
    y_store_feq = get_line_de('store_feq',7,4)[0][1:11]
    y_lib_feq = get_line_de('lib_feq',7,4)[0][1:11]

    y_full_pec = get_line_de('full_pec',7,4)[0][1:11]

    y_rdt_r = [i*100 for i in y_rdt_r]
    y_rdt_w = [i*100 for i in y_rdt_w]
    y_rds_r = [i*100 for i in y_rds_r]
    y_rds_over = [i*100 for i in y_rds_over]
    y_rdt_over = [i*100 for i in y_rdt_over]
    y_other= [i*100 for i in y_other]
    y_over= [i*100 for i in y_over]

    y_load_pec = [i*100 for i in y_load_pec]
    y_store_pec= [i*100 for i in y_store_pec]
    y_lib_pec= [i*100 for i in y_lib_pec]

    y_load_feq = [i*1000 for i in y_load_feq]
    y_store_feq = [i*1000 for i in y_store_feq]
    y_lib_feq = [i*1000 for i in y_lib_feq]

    y_full_pec= [i*100 for i in y_full_pec]

    print(y_rdt_r)
    print(y_rdt_w)
    print(y_rds_r)
    print(y_rds_over)
    print(y_rdt_over)
    print(y_other)

    print(y_load_pec)
    print(y_store_pec)
    print(y_lib_pec)

    print(y_load_feq)
    print(y_store_feq)
    print(y_lib_feq)

    print(y_full_pec)

    bottom1 = (np.array(y_rds_r) - np.array(y_rds_over)).tolist()
    bottom2 = (np.array(bottom1) + np.array(y_other) - np.array(y_rdt_over)).tolist()
    bottom3 = np.sum([bottom2,y_rdt_w],axis=0).tolist()
    boo = np.array(y_load_pec) + np.array(y_store_pec)
    boo = boo.tolist()

    x_0 = [i-0.15-0.1 for i in x_widht]
    x_1 = [i for i in x_widht]
    x_2 = [i+0.2 for i in x_widht]
    y_0 = [0 for i in x_widht]

    l0 = ax.bar(x_0,y_other,width=0.3,color = 'white',ec='k',bottom = bottom1,lw=1.5)
    l1 = ax.bar(x_0,y_rds_r,width=0.2, color = rgb_limit0[0],ec='k',lw=1.5)
    l2 = ax.bar(x_0,y_rdt_w,width=0.2, color = rgb_limit1[0],ec='k',bottom = bottom2,lw=1.5)
    l3 = ax.bar(x_0,y_rdt_r,width=0.2, color = rgb_limit1[1],ec='k',bottom = bottom3,lw=1.5)

    l4 = ax.bar(x_1,y_load_pec,width=0.2, color = 'white',ec=rgb_limit1[1],lw=1.5)
    l5 = ax.bar(x_1,y_store_pec,width=0.2, color = 'white', hatch = '/'*2,ec=rgb_limit1[1],bottom = y_load_pec,lw=1.5)
    l6 = ax.bar(x_1,y_lib_pec,width=0.2, color = 'white', hatch = '\\'*2,ec=rgb_limit1[1],bottom = boo,lw=1.5)

    l7 = ax.bar(x_2,y_full_pec,width=0.2, color = 'white',ec='darkblue',lw=1.5)

    l660 = ax2.plot(x_2,y_0, lw=0)
    l8=ax2.plot(x_widht,y_load_feq, color='black',marker='s',markersize=8,markerfacecolor='white',linestyle='-',lw=2)
    l9=ax2.plot(x_widht,y_store_feq, color='black',marker='o',markersize=8,linestyle='--',lw=2)
    l10=ax2.plot(x_widht,y_lib_feq, color='black',marker='^',markersize=10,markerfacecolor='white',linestyle=':',lw=2)

    l66 = ax.bar(x_2,y_0,width=0.2, color = 'white')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    ax2.set_ylim(-2,66) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(range(0,10),x_name,rotation=0,fontsize=17)
    ax.set_ylabel('DFI\nTime Cost Breakdown (%)',fontsize=15,color=rgb_limit1[1])
    ax2.set_ylabel('Freq. (# / 1000 cycles)',fontsize=15)
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    ll0=ax.legend((l0,l1,l2,l3),['Other Mon. Inst.','Load RDS and Check','Update RDT','Load RDT'],
            loc='upper right',bbox_to_anchor=(0.3,1.65),ncol=1,fontsize=14)
    ax.add_artist(ll0)
    ll1=ax.legend((l66,l4,l5,l6),['','Load Req.','Store Req.','Lib Req.'],
            loc='upper right',bbox_to_anchor=(0.5,1.65),ncol=1,fontsize=14)
    ax.add_artist(ll1)
    ax.legend((l66,l66,l66,l7),['','','','FIFO Full'],
            loc='upper right',bbox_to_anchor=(0.8,1.65),ncol=1,fontsize=14)


    ax.grid(linestyle = ":")
    ax2.legend(['','Load Req.','Store Req.','Lib Req.'],loc='upper right',bbox_to_anchor=(1,1.65),ncol=1,fontsize=14)
    ax.tick_params(labelsize=15)
    ax.tick_params(axis='y',colors=rgb_limit1[1])
    ax2.tick_params(labelsize=15)


def draw_shadow_stack(ax):
    x_widht = range(0,10)

    # fig = plt.figure(figsize=(10,3))  # 创建画布
    # ax = plt.gca()
    ax2 = ax.twinx()


    y_store_pec = get_line_de('store_pec',7,0)[0][1:11]
    y_load_pec = get_line_de('load_pec',7,0)[0][1:11]
    y_other_pec = get_line_de('other_pec',7,0)[0][1:11]
    y_store_over = get_line_de('store_over',7,0)[0][1:11]

    y_ret_pec = get_line_de('pop_pec',7,0)[0][1:11]
    y_call_pec = get_line_de('push_pec',7,0)[0][1:11]

    y_call_feq = get_line_de('call_feq',7,0)[0][1:11]
    y_full_pec = get_line_de('full_pec',7,0)[0][1:11]

    y_store_pec = [i*100 for i in y_store_pec]
    y_load_pec = [i*100 for i in y_load_pec]
    y_other_pec = [i*100 for i in y_other_pec]
    y_store_over = [i*100 for i in y_store_over]

    y_ret_pec = [i*100 for i in y_ret_pec]
    y_call_pec = [i*100 for i in y_call_pec]

    y_full_pec= [i*10000 for i in y_full_pec]

    y_call_feq = [i*10000 for i in y_call_feq]


    print(y_store_pec)
    print(y_load_pec)
    print(y_other_pec)
    print(y_store_over)

    print(y_ret_pec)
    print(y_call_pec)

    print(y_full_pec)
    print(y_call_feq)


    bottom1 = (np.array(y_store_pec) - np.array(y_store_over)).tolist()
    bottom2 = np.sum([bottom1,y_other_pec],axis=0).tolist()
    boo = np.array(y_load_pec) + np.array(y_store_pec)
    boo = boo.tolist()

    x_0 = [i-0.15-0.1 for i in x_widht]
    x_1 = [i for i in x_widht]
    x_2 = [i+0.2 for i in x_widht]
    y_0 = [0 for i in x_widht]

    l0 = ax.bar(x_0,y_other_pec,width=0.3,color = 'white',ec='k',bottom = bottom1,lw=1.5)
    l1 = ax.bar(x_0,y_store_pec,width=0.2, color = rgb_limit1[0],ec='k',lw=1.5)
    l2 = ax.bar(x_0,y_load_pec,width=0.2, color = rgb_limit1[1],ec='k',bottom = bottom2,lw=1.5)

    l3 = ax.bar(x_1,y_call_pec,width=0.2, color = 'white',ec=rgb_limit1[1],lw=1.5)
    l4 = ax.bar(x_1,y_ret_pec,width=0.2, color = 'white', hatch = '/'*2,ec=rgb_limit1[1],bottom = y_call_pec,lw=1.5)

    l5 = ax.bar(x_2,y_full_pec,width=0.2, color = 'white',ec='darkblue',lw=1.5)

    # l6=ax2.plot(x_widht,y_0, lw=0)
    l7=ax2.plot(x_widht,y_0, lw=0)
    l8=ax2.plot(x_widht,y_call_feq, color='black',marker='s',markersize=8,markerfacecolor='white',linestyle='-',lw=2)
    l9=ax2.plot(x_widht,y_call_feq, color='black',marker='.',markersize=9,linestyle='-',lw=2)

    l66 = ax.bar(x_2,y_0,width=0.2, color = 'white')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    ax2.set_ylim(-2,62) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(range(0,10),x_name,rotation=0,fontsize=17)
    ax.set_ylabel('Shadow Stack\nTime Cost Breakdown(%)',fontsize=15,color=rgb_limit1[1])
    ax2.set_ylabel('Freq. (# / 10000 cycles)',fontsize=15)
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    l11 = ax.legend((l0,l1,l2),['Other Mon. Inst.','Push Stack','Pop Stack','','Call Req.','Ret Req.','','','FIFO Full Time (* 100)'],
            loc='upper right',bbox_to_anchor=(0.24,1.52),ncol=1,fontsize=14)
    ax.add_artist(l11)
    l22 = ax.legend((l66,l3,l4),['','Call Req.','Ret Req.','','','FIFO Full (* 100)'],
            loc='upper right',bbox_to_anchor=(0.5,1.52),ncol=1,fontsize=14)
    ax.add_artist(l22)
    l22 = ax.legend((l66,l66,l5),['','','FIFO Full (* 100)'],
            loc='upper right',bbox_to_anchor=(0.8,1.52),ncol=1,fontsize=14)
    # ax.add_artist(l1)
    # ax.legend((None,h11),['FIFO Full Time','',''], loc='upper right',bbox_to_anchor=(0.6,1),ncol=2,fontsize=14)
    ax.grid(linestyle = ":")
    ax2.legend(['','Call Req.','Ret Req.'],loc='upper right',bbox_to_anchor=(1,1.52),ncol=1,fontsize=14)
    ax.tick_params(labelsize=15)
    ax.tick_params(axis='y',colors=rgb_limit1[1])
    ax2.tick_params(labelsize=15)


def draw_shadow_stack_opt(ax):
    x_widht = range(0,len(opt_case_name))

    # fig = plt.figure(figsize=(10,3))  # 创建画布
    # ax = plt.gca()


    y_store_pec_all = get_line_de('store_pec',7,0)[0][10]
    y_load_pec_all = get_line_de('load_pec',7,0)[0][10]
    y_other_pec_all = get_line_de('other_pec',7,0)[0][10]
    y_store_over_all = get_line_de('store_over',7,0)[0][10]

    y_ret_pec_all = get_line_de('pop_pec',7,0)[0][10]
    y_call_pec_all = get_line_de('push_pec',7,0)[0][10]
    y_full_pec_all = get_line_de('full_pec',7,0)[0][10]


    y_store_pec_no = get_line_de('store_pec',0,0)[0][10]
    y_load_pec_no = get_line_de('load_pec',0,0)[0][10]
    y_other_pec_no = get_line_de('other_pec',0,0)[0][10]
    y_store_over_no = get_line_de('store_over',0,0)[0][10]

    y_ret_pec_no = get_line_de('pop_pec',0,0)[0][10]
    y_call_pec_no = get_line_de('push_pec',0,0)[0][10]
    y_full_pec_no = get_line_de('full_pec',0,0)[0][10]

    y_store_pec_8k = get_line_de('store_pec',1,0)[0][10]
    y_load_pec_8k = get_line_de('load_pec',1,0)[0][10]
    y_other_pec_8k = get_line_de('other_pec',1,0)[0][10]
    y_store_over_8k = get_line_de('store_over',1,0)[0][10]

    y_ret_pec_8k = get_line_de('pop_pec',1,0)[0][10]
    y_call_pec_8k = get_line_de('push_pec',1,0)[0][10]
    y_full_pec_8k = get_line_de('full_pec',1,0)[0][10]

    y_store_pec_1k = get_line_de('store_pec',2,0)[0][10]
    y_load_pec_1k = get_line_de('load_pec',2,0)[0][10]
    y_other_pec_1k = get_line_de('other_pec',2,0)[0][10]
    y_store_over_1k = get_line_de('store_over',2,0)[0][10]

    y_ret_pec_1k = get_line_de('pop_pec',2,0)[0][10]
    y_call_pec_1k = get_line_de('push_pec',2,0)[0][10]
    y_full_pec_1k = get_line_de('full_pec',2,0)[0][10]


    y_store_pec_ooo = get_line_de('store_pec',5,0)[0][10]
    y_load_pec_ooo = get_line_de('load_pec',5,0)[0][10]
    y_other_pec_ooo = get_line_de('other_pec',5,0)[0][10]
    y_store_over_ooo = get_line_de('store_over',5,0)[0][10]

    y_ret_pec_ooo = get_line_de('pop_pec',5,0)[0][10]
    y_call_pec_ooo = get_line_de('push_pec',5,0)[0][10]
    y_full_pec_ooo = get_line_de('full_pec',5,0)[0][10]

    y_store_pec = [y_store_pec_no,y_store_pec_1k,y_store_pec_8k,0,0,y_store_pec_ooo,0,y_store_pec_all]
    y_store_pec = [i*100 for i in y_store_pec]
    y_load_pec = [y_load_pec_no,y_load_pec_1k,y_load_pec_8k,0,0,y_load_pec_ooo,0,y_load_pec_all]
    y_load_pec = [i*100 for i in y_load_pec]
    y_other_pec = [y_other_pec_no,y_other_pec_1k,y_other_pec_8k,0,0,y_other_pec_ooo,0,y_other_pec_all]
    y_other_pec = [i*100 for i in y_other_pec]
    y_store_over = [y_store_over_no,y_store_over_1k,y_store_over_8k,0,0,y_store_over_ooo,0,y_store_over_all]
    y_store_over = [i*100 for i in y_store_over]

    y_ret_pec = [y_ret_pec_no,y_ret_pec_1k,y_ret_pec_8k,0,0,y_ret_pec_ooo,0,y_ret_pec_all]
    y_ret_pec = [i*100 for i in y_ret_pec]
    y_call_pec = [y_call_pec_no,y_call_pec_1k,y_call_pec_8k,0,0,y_call_pec_ooo,0,y_call_pec_all]
    y_call_pec = [i*100 for i in y_call_pec]

    y_full_pec = [y_full_pec_no,y_full_pec_1k,y_full_pec_8k,0,0,y_full_pec_ooo,0,y_full_pec_all]
    y_full_pec= [i*10000 for i in y_full_pec]



    print(y_store_pec)
    print(y_load_pec)
    print(y_other_pec)
    print(y_store_over)

    print(y_ret_pec)
    print(y_call_pec)

    print(y_full_pec)


    bottom1 = (np.array(y_store_pec) - np.array(y_store_over)).tolist()
    bottom2 = np.sum([bottom1,y_other_pec],axis=0).tolist()
    boo = np.array(y_load_pec) + np.array(y_store_pec)
    boo = boo.tolist()

    x_0 = [i-0.15-0.1 for i in x_widht]
    x_1 = [i for i in x_widht]
    x_2 = [i+0.2 for i in x_widht]
    y_0 = [0 for i in x_widht]

    l0 = ax.bar(x_0,y_other_pec,width=0.3,color = 'white',ec='k',bottom = bottom1,lw=1.5)
    l1 = ax.bar(x_0,y_store_pec,width=0.2, color = rgb_limit1[0],ec='k',lw=1.5)
    l2 = ax.bar(x_0,y_load_pec,width=0.2, color = rgb_limit1[1],ec='k',bottom = bottom2,lw=1.5)

    l3 = ax.bar(x_1,y_call_pec,width=0.2, color = 'white',ec=rgb_limit1[1],lw=1.5)
    l4 = ax.bar(x_1,y_ret_pec,width=0.2, color = 'white', hatch = '/'*2,ec=rgb_limit1[1],bottom = y_call_pec,lw=1.5)

    l5 = ax.bar(x_2,y_full_pec,width=0.2, color = 'white',ec='darkblue',lw=1.5)


    l66 = ax.bar(x_2,y_0,width=0.2, color = 'white')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    # x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(x_widht,opt_case_name,rotation=30,fontsize=17)
    ax.set_ylabel('Shadow Stack\nTime Cost Breakdown(%)',fontsize=15,color=rgb_limit1[1])
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    l11 = ax.legend((l0,l1,l2),['Other Mon Inst.','Push Stack','Pop Stack'],
            loc='upper right',bbox_to_anchor=(0.25,1.55),ncol=1,fontsize=14)
    ax.add_artist(l11)
    l22 = ax.legend((l66,l3,l4),['','Call Req.','Ret Req.',''],
            loc='upper right',bbox_to_anchor=(0.6,1.55),ncol=1,fontsize=14)
    ax.add_artist(l22)
    l22 = ax.legend((l66,l66,l5),['','','FIFO Full (* 100)'],
            loc='upper right',bbox_to_anchor=(1,1.55),ncol=1,fontsize=14)
    # ax.legend((None,h11),['FIFO Full Time','',''], loc='upper right',bbox_to_anchor=(0.6,1),ncol=2,fontsize=14)
    ax.grid(linestyle = ":")
    ax.tick_params(labelsize=15)
    ax.tick_params(axis='y',colors=rgb_limit1[1])

  
    # plt.savefig('ss_resopt.pdf',dpi=300, bbox_inches='tight')
    # plt.show()

def draw_lw_dift(ax):
    x_widht = range(0,10)

    # fig = plt.figure(figsize=(10,3))  # 创建画布
    # ax = plt.gca()
    ax2 = ax.twinx()


    y_mm_store_pec = get_line_de('mm_store_pec',7,3)[0][1:11]
    y_mm_load_pec = get_line_de('mm_load_pec',7,3)[0][1:11]
    y_mm_other_pec = get_line_de('mm_other_pec',7,3)[0][1:11]
    y_mm_store_over = get_line_de('mm_store_over',7,3)[0][1:11]

    y_store_pec = get_line_de('store_pec',7,3)[0][1:11]
    y_lib_pec = get_line_de('lib_pec',7,3)[0][1:11]
    y_load_pec = get_line_de('load_pec',7,3)[0][1:11]

    y_load_feq = get_line_de('load_feq',7,3)[0][1:11]
    y_store_feq = get_line_de('store_feq',7,3)[0][1:11]
    y_lib_feq = get_line_de('lib_feq',7,3)[0][1:11]

    y_full_pec = get_line_de('full_pec',7,3)[0][1:11]

    y_mm_store_pec = [i*100 for i in y_mm_store_pec]
    y_mm_load_pec = [i*100 for i in y_mm_load_pec]
    y_mm_other_pec = [i*100 for i in y_mm_other_pec]
    y_mm_store_over = [i*100 for i in y_mm_store_over]

    y_store_pec = [i*100 for i in y_store_pec]
    y_lib_pec = [i*100 for i in y_lib_pec]
    y_load_pec = [i*100 for i in y_load_pec]

    y_store_feq = [i*1000 for i in y_store_feq]
    y_lib_feq = [i*1000 for i in y_lib_feq]
    y_load_feq = [i*1000 for i in y_load_feq]

    y_full_pec = [i*100 for i in y_full_pec]

    print(y_mm_store_pec)
    print(y_mm_load_pec)
    print(y_mm_other_pec)
    print(y_mm_store_over)

    print(y_store_pec)
    print(y_load_pec)
    print(y_lib_pec)

    print(y_full_pec)

    print(y_lib_feq)
    print(y_load_feq)
    print(y_store_feq)


    bottom1 = (np.array(y_mm_store_pec) - np.array(y_mm_store_over)).tolist()
    bottom2 = np.sum([bottom1,y_mm_other_pec],axis=0).tolist()
    boo = np.array(y_load_pec) + np.array(y_store_pec)
    boo = boo.tolist()

    x_0 = [i-0.15-0.1 for i in x_widht]
    x_1 = [i for i in x_widht]
    x_2 = [i+0.2 for i in x_widht]
    y_0 = [0 for i in x_widht]

    l0 = ax.bar(x_0,y_mm_other_pec,width=0.3,color = 'white',ec='k',bottom = bottom1,lw=1.5)
    l1 = ax.bar(x_0,y_mm_store_pec,width=0.2, color = rgb_limit1[0],ec='k',lw=1.5)
    l2 = ax.bar(x_0,y_mm_load_pec,width=0.2, color = rgb_limit1[1],ec='k',bottom = bottom2,lw=1.5)

    l3 = ax.bar(x_1,y_load_pec,width=0.2, color = 'white',ec=rgb_limit1[1],lw=1.5)
    l4 = ax.bar(x_1,y_store_pec,width=0.2, color = 'white', hatch = '/'*2,ec=rgb_limit1[1],bottom = y_load_pec,lw=1.5)
    l5 = ax.bar(x_1,y_lib_pec,width=0.2, color = 'white', hatch = '\\'*2,ec=rgb_limit1[1],bottom = boo,lw=1.5)

    l6 = ax.bar(x_2,y_full_pec,width=0.2, color = 'white',ec='darkblue',lw=1.5)

    # ax2.plot(x_widht,y_load_feq,lw=0)
    ax2.plot(x_widht,y_load_feq, color='black',marker='s',markersize=8,markerfacecolor='white',linestyle='-',lw=2)
    ax2.plot(x_widht,y_store_feq, color='black',marker='o',markersize=8,linestyle='--',lw=2)
    ax2.plot(x_widht,y_lib_feq, color='black',marker='^',markersize=10,markerfacecolor='white',linestyle=':',lw=2)


    l66 = ax.bar(x_2,y_0,width=0.2, color = 'white')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    ax2.set_ylim(-2,66) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(range(0,10),x_name,rotation=0,fontsize=17)
    ax.set_ylabel('LW-DIFT\nTime Cost Breakdown (%)',fontsize=15,color=rgb_limit1[1])
    ax2.set_ylabel('Freq. (# / 1000 cycles)',fontsize=15)
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    l11 = ax.legend((l0,l1,l2),['Other Mon. Inst.','Update Tag Table','Load Tag Table     ','Load Mon. Time','Store Mon. Time','Lib Mon. ','','','FIFO Full Time'],
            loc='upper right',bbox_to_anchor=(0.275,1.52),ncol=1,fontsize=14)
    ax.add_artist(l11)
    l22 = ax.legend((l3,l4,l5),['Load Req.','Store Req.','Lib Req.','','','FIFO Full '],
            loc='upper right',bbox_to_anchor=(0.5,1.52),ncol=1,fontsize=14)
    ax.add_artist(l22)
    l22 = ax.legend((l66,l66,l6),['','','FIFO Full '],
            loc='upper right',bbox_to_anchor=(0.8,1.52),ncol=1,fontsize=14)
    # ax.legend((None,h11),['FIFO Full Time','',''], loc='upper right',bbox_to_anchor=(0.6,1),ncol=2,fontsize=14)
    ax.grid(linestyle = ":")
    ax2.legend(['Load Req.','Store Req.','Lib Req.'],loc='upper right',bbox_to_anchor=(1.,1.52),ncol=1,fontsize=14)
    ax.tick_params(labelsize=15)
    ax.tick_params(axis='y',colors=rgb_limit1[1])
    ax2.tick_params(labelsize=15)



def draw_lw_diftopt(ax):
    x_widht = range(0,len(opt_case_name))

    # fig = plt.figure(figsize=(10,3))  # 创建画布
    # ax = plt.gca()


    y_mm_store_pec_all = get_line_de('mm_store_pec',7,3)[0][10]
    y_mm_load_pec_all = get_line_de('mm_load_pec',7,3)[0][10]
    y_mm_other_pec_all = get_line_de('mm_other_pec',7,3)[0][10]
    y_mm_store_over_all = get_line_de('mm_store_over',7,3)[0][10]
    y_store_pec_all = get_line_de('store_pec',7,3)[0][10]
    y_lib_pec_all = get_line_de('lib_pec',7,3)[0][10]
    y_load_pec_all = get_line_de('load_pec',7,3)[0][10]
    y_full_pec_all = get_line_de('full_pec',7,3)[0][10]

    y_mm_store_pec_no = get_line_de('mm_store_pec',0,3)[0][10]
    y_mm_load_pec_no = get_line_de('mm_load_pec',0,3)[0][10]
    y_mm_other_pec_no = get_line_de('mm_other_pec',0,3)[0][10]
    y_mm_store_over_no = get_line_de('mm_store_over',0,3)[0][10]
    y_store_pec_no = get_line_de('store_pec',0,3)[0][10]
    y_lib_pec_no = get_line_de('lib_pec',0,3)[0][10]
    y_load_pec_no = get_line_de('load_pec',0,3)[0][10]
    y_full_pec_no = get_line_de('full_pec',0,3)[0][10]

    y_mm_store_pec_8k = get_line_de('mm_store_pec',1,3)[0][10]
    y_mm_load_pec_8k = get_line_de('mm_load_pec',1,3)[0][10]
    y_mm_other_pec_8k = get_line_de('mm_other_pec',1,3)[0][10]
    y_mm_store_over_8k = get_line_de('mm_store_over',1,3)[0][10]
    y_store_pec_8k = get_line_de('store_pec',1,3)[0][10]
    y_lib_pec_8k = get_line_de('lib_pec',1,3)[0][10]
    y_load_pec_8k = get_line_de('load_pec',1,3)[0][10]
    y_full_pec_8k = get_line_de('full_pec',1,3)[0][10]

    y_mm_store_pec_1k = get_line_de('mm_store_pec',2,3)[0][10]
    y_mm_load_pec_1k = get_line_de('mm_load_pec',2,3)[0][10]
    y_mm_other_pec_1k = get_line_de('mm_other_pec',2,3)[0][10]
    y_mm_store_over_1k = get_line_de('mm_store_over',2,3)[0][10]
    y_store_pec_1k = get_line_de('store_pec',2,3)[0][10]
    y_lib_pec_1k = get_line_de('lib_pec',2,3)[0][10]
    y_load_pec_1k = get_line_de('load_pec',2,3)[0][10]
    y_full_pec_1k = get_line_de('full_pec',2,3)[0][10]

    y_mm_store_pec_ooo = get_line_de('mm_store_pec',5,3)[0][10]
    y_mm_load_pec_ooo = get_line_de('mm_load_pec',5,3)[0][10]
    y_mm_other_pec_ooo = get_line_de('mm_other_pec',5,3)[0][10]
    y_mm_store_over_ooo = get_line_de('mm_store_over',5,3)[0][10]
    y_store_pec_ooo = get_line_de('store_pec',5,3)[0][10]
    y_lib_pec_ooo = get_line_de('lib_pec',5,3)[0][10]
    y_load_pec_ooo = get_line_de('load_pec',5,3)[0][10]
    y_full_pec_ooo = get_line_de('full_pec',5,3)[0][10]


    y_mm_store_pec = [y_mm_store_pec_no,y_mm_store_pec_1k,y_mm_store_pec_8k,0,0,y_mm_store_pec_ooo,0,y_mm_store_pec_all]
    y_mm_store_pec = [i*100 for i in y_mm_store_pec]
    y_mm_load_pec = [y_mm_load_pec_no,y_mm_load_pec_1k,y_mm_load_pec_8k,0,0,y_mm_load_pec_ooo,0,y_mm_load_pec_all]
    y_mm_load_pec = [i*100 for i in y_mm_load_pec]
    y_mm_other_pec = [y_mm_other_pec_no,y_mm_other_pec_1k,y_mm_other_pec_8k,0,0,y_mm_other_pec_ooo,0,y_mm_other_pec_all]
    y_mm_other_pec = [i*100 for i in y_mm_other_pec]
    y_mm_store_over= [y_mm_store_over_no,y_mm_store_over_1k,y_mm_store_over_8k,0,0,y_mm_store_over_ooo,0,y_mm_store_over_all]
    y_mm_store_over = [i*100 for i in y_mm_store_over]

    y_store_pec = [y_store_pec_no,y_store_pec_1k,y_store_pec_8k,0,0,y_store_pec_ooo,0,y_store_pec_all]
    y_store_pec = [i*100 for i in y_store_pec]
    y_lib_pec = [y_lib_pec_no,y_lib_pec_1k,y_lib_pec_8k,0,0,y_lib_pec_ooo,0,y_lib_pec_all]
    y_lib_pec = [i*100 for i in y_lib_pec]
    y_load_pec= [y_load_pec_no,y_load_pec_1k,y_load_pec_8k,0,0,y_load_pec_ooo,0,y_load_pec_all]
    y_load_pec = [i*100 for i in y_load_pec]


    y_full_pec = [y_full_pec_no,y_full_pec_1k,y_full_pec_8k,0,0,y_full_pec_ooo,0,y_full_pec_all]
    y_full_pec = [i*100 for i in y_full_pec]

    print(y_mm_store_pec)
    print(y_mm_load_pec)
    print(y_mm_other_pec)
    print(y_mm_store_over)

    print(y_store_pec)
    print(y_load_pec)
    print(y_lib_pec)

    print(y_full_pec)


    bottom1 = (np.array(y_mm_store_pec) - np.array(y_mm_store_over)).tolist()
    bottom2 = np.sum([bottom1,y_mm_other_pec],axis=0).tolist()
    boo = np.array(y_load_pec) + np.array(y_store_pec)
    boo = boo.tolist()

    x_0 = [i-0.15-0.1 for i in x_widht]
    x_1 = [i for i in x_widht]
    x_2 = [i+0.2 for i in x_widht]
    y_0 = [0 for i in x_widht]

    l0 = ax.bar(x_0,y_mm_other_pec,width=0.3,color = 'white',ec='k',bottom = bottom1,lw=1.5)
    l1 = ax.bar(x_0,y_mm_store_pec,width=0.2, color = rgb_limit1[0],ec='k',lw=1.5)
    l2 = ax.bar(x_0,y_mm_load_pec,width=0.2, color = rgb_limit1[1],ec='k',bottom = bottom2,lw=1.5)

    l3 = ax.bar(x_1,y_load_pec,width=0.2, color = 'white',ec=rgb_limit1[1],lw=1.5)
    l4 = ax.bar(x_1,y_store_pec,width=0.2, color = 'white', hatch = '/'*2,ec=rgb_limit1[1],bottom = y_load_pec,lw=1.5)
    l5 = ax.bar(x_1,y_lib_pec,width=0.2, color = 'white', hatch = '\\'*2,ec=rgb_limit1[1],bottom = boo,lw=1.5)

    l6 = ax.bar(x_2,y_full_pec,width=0.2, color = 'white',ec='darkblue',lw=1.5)



    l66 = ax.bar(x_2,y_0,width=0.2, color = 'white')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    ax.set_xticks(x_widht,opt_case_name,rotation=30,fontsize=17)
    ax.set_ylabel('LW-DIFT\nTime Cost Breakdown (%)',fontsize=15,color=rgb_limit1[1])
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    l11 = ax.legend((l0,l1,l2),['Other Mon. Inst.','Update Tag Table','Load Tag Table','Load Mon. Time','Store Mon. Time','Lib Mon. Time','','','FIFO Full Time'],
            loc='upper right',bbox_to_anchor=(0.26,1.55),ncol=1,fontsize=14)
    ax.add_artist(l11)
    l22 = ax.legend((l3,l4,l5),['Load Req.','Store Req.','Lib Req.'],
            loc='upper right',bbox_to_anchor=(0.6,1.55),ncol=1,fontsize=14)
    ax.add_artist(l22)
    l22 = ax.legend((l66,l66,l6),['','','FIFO Full'],
            loc='upper right',bbox_to_anchor=(1,1.55),ncol=1,fontsize=14)
    ax.grid(linestyle = ":")
    ax.tick_params(labelsize=15)
    ax.tick_params(axis='y',colors=rgb_limit1[1])
  
    # plt.savefig('lwdift_resopt.pdf',dpi=300, bbox_inches='tight')
    # plt.show()


def draw_cfi_opt(ax):
    x_widht = range(0,len(opt_case))

    # fig = plt.figure(figsize=(10,3))  # 创建画布
    # ax = plt.gca()


    y_pop_all = get_line_de('mm_load_pec',7,2)[0][10]
    y_push_all = get_line_de('mm_store_pec',7,2)[0][10]
    y_cfg_r_all = get_line_de('mm_check_pec',7,2)[0][10]
    y_cfg_over_all = get_line_de('mm_check_over',7,2)[0][10]
    y_store_over_all = get_line_de('mm_store_over',7,2)[0][10]
    y_other_all = get_line_de('mm_other_pec',7,2)[0][10]
    y_over_all = get_line_de('overlap_pec',7,2)[0][10]
    y_call_pec_all = get_line_de('call_pec',7,2)[0][10]
    y_ret_pec_all = get_line_de('ret_pec',7,2)[0][10]
    y_jalr_pec_all = get_line_de('jalr_pec',7,2)[0][10]
    y_full_pec_all = get_line_de('full_pec',7,2)[0][10]

    y_pop_no = get_line_de('mm_load_pec',0,2)[0][10]
    y_push_no = get_line_de('mm_store_pec',0,2)[0][10]
    y_cfg_r_no = get_line_de('mm_check_pec',0,2)[0][10]
    y_cfg_over_no = get_line_de('mm_check_over',0,2)[0][10]
    y_store_over_no = get_line_de('mm_store_over',0,2)[0][10]
    y_other_no = get_line_de('mm_other_pec',0,2)[0][10]
    y_over_no = get_line_de('overlap_pec',0,2)[0][10]
    y_call_pec_no = get_line_de('call_pec',0,2)[0][10]
    y_ret_pec_no = get_line_de('ret_pec',0,2)[0][10]
    y_jalr_pec_no = get_line_de('jalr_pec',0,2)[0][10]
    y_full_pec_no = get_line_de('full_pec',0,2)[0][10]

    y_pop_8k = get_line_de('mm_load_pec',1,2)[0][10]
    y_push_8k = get_line_de('mm_store_pec',1,2)[0][10]
    y_cfg_r_8k = get_line_de('mm_check_pec',1,2)[0][10]
    y_cfg_over_8k = get_line_de('mm_check_over',1,2)[0][10]
    y_store_over_8k = get_line_de('mm_store_over',1,2)[0][10]
    y_other_8k = get_line_de('mm_other_pec',1,2)[0][10]
    y_over_8k = get_line_de('overlap_pec',1,2)[0][10]
    y_call_pec_8k = get_line_de('call_pec',1,2)[0][10]
    y_ret_pec_8k = get_line_de('ret_pec',1,2)[0][10]
    y_jalr_pec_8k = get_line_de('jalr_pec',1,2)[0][10]
    y_full_pec_8k = get_line_de('full_pec',1,2)[0][10]

    y_pop_1k = get_line_de('mm_load_pec',2,2)[0][10]
    y_push_1k = get_line_de('mm_store_pec',2,2)[0][10]
    y_cfg_r_1k = get_line_de('mm_check_pec',2,2)[0][10]
    y_cfg_over_1k = get_line_de('mm_check_over',2,2)[0][10]
    y_store_over_1k = get_line_de('mm_store_over',2,2)[0][10]
    y_other_1k = get_line_de('mm_other_pec',2,2)[0][10]
    y_over_1k = get_line_de('overlap_pec',2,2)[0][10]
    y_call_pec_1k = get_line_de('call_pec',2,2)[0][10]
    y_ret_pec_1k = get_line_de('ret_pec',2,2)[0][10]
    y_jalr_pec_1k = get_line_de('jalr_pec',2,2)[0][10]
    y_full_pec_1k = get_line_de('full_pec',2,2)[0][10]

    y_pop_rlb256 = get_line_de('mm_load_pec',4,2)[0][10]
    y_push_rlb256 = get_line_de('mm_store_pec',4,2)[0][10]
    y_cfg_r_rlb256 = get_line_de('mm_check_pec',4,2)[0][10]
    y_cfg_over_rlb256 = get_line_de('mm_check_over',4,2)[0][10]
    y_store_over_rlb256 = get_line_de('mm_store_over',4,2)[0][10]
    y_other_rlb256 = get_line_de('mm_other_pec',4,2)[0][10]
    y_over_rlb256 = get_line_de('overlap_pec',4,2)[0][10]
    y_call_pec_rlb256 = get_line_de('call_pec',4,2)[0][10]
    y_ret_pec_rlb256 = get_line_de('ret_pec',4,2)[0][10]
    y_jalr_pec_rlb256 = get_line_de('jalr_pec',4,2)[0][10]
    y_full_pec_rlb256 = get_line_de('full_pec',4,2)[0][10]

    y_pop_rlb1k = get_line_de('mm_load_pec',3,2)[0][10]
    y_push_rlb1k = get_line_de('mm_store_pec',3,2)[0][10]
    y_cfg_r_rlb1k = get_line_de('mm_check_pec',3,2)[0][10]
    y_cfg_over_rlb1k = get_line_de('mm_check_over',3,2)[0][10]
    y_store_over_rlb1k = get_line_de('mm_store_over',3,2)[0][10]
    y_other_rlb1k = get_line_de('mm_other_pec',3,2)[0][10]
    y_over_rlb1k = get_line_de('overlap_pec',3,2)[0][10]
    y_call_pec_rlb1k = get_line_de('call_pec',3,2)[0][10]
    y_ret_pec_rlb1k = get_line_de('ret_pec',3,2)[0][10]
    y_jalr_pec_rlb1k = get_line_de('jalr_pec',3,2)[0][10]
    y_full_pec_rlb1k = get_line_de('full_pec',3,2)[0][10]

    y_pop_ooo = get_line_de('mm_load_pec',5,2)[0][10]
    y_push_ooo= get_line_de('mm_store_pec',5,2)[0][10]
    y_cfg_r_ooo= get_line_de('mm_check_pec',5,2)[0][10]
    y_cfg_over_ooo= get_line_de('mm_check_over',5,2)[0][10]
    y_store_over_ooo= get_line_de('mm_store_over',5,2)[0][10]
    y_other_ooo= get_line_de('mm_other_pec',5,2)[0][10]
    y_over_ooo= get_line_de('overlap_pec',5,2)[0][10]
    y_call_pec_ooo= get_line_de('call_pec',5,2)[0][10]
    y_ret_pec_ooo= get_line_de('ret_pec',5,2)[0][10]
    y_jalr_pec_ooo= get_line_de('jalr_pec',5,2)[0][10]
    y_full_pec_ooo= get_line_de('full_pec',5,2)[0][10]

    y_pop = [y_pop_no,y_pop_1k,y_pop_8k,y_pop_rlb256,y_pop_rlb1k,y_pop_ooo,0,y_pop_all]
    y_pop = [i*100 for i in y_pop]
    y_push = [y_push_no,y_push_1k,y_push_8k,y_push_rlb256,y_push_rlb1k,y_push_ooo,0,y_push_all]
    y_push = [i*100 for i in y_push]
    y_cfg_r= [y_cfg_r_no,y_cfg_r_1k,y_cfg_r_8k,y_cfg_r_rlb256,y_cfg_r_rlb1k,y_cfg_r_ooo,0,y_cfg_r_all]
    y_cfg_r = [i*100 for i in y_cfg_r]
    y_cfg_over= [y_cfg_over_no,y_cfg_over_1k,y_cfg_over_8k,y_cfg_over_rlb256,y_cfg_over_rlb1k,y_cfg_over_ooo,0,y_cfg_over_all]
    y_cfg_over = [i*100 for i in y_cfg_over]
    y_store_over= [y_store_over_no,y_store_over_1k,y_store_over_8k,y_store_over_rlb256,y_store_over_rlb1k,y_store_over_ooo,0,y_store_over_all]
    y_store_over = [i*100 for i in y_store_over]
    y_other= [y_other_no,y_other_1k,y_other_8k,y_other_rlb256,y_other_rlb1k,y_other_ooo,0,y_other_all]
    y_other= [i*100 for i in y_other]

    y_call_pec = [y_call_pec_no,y_call_pec_1k,y_call_pec_8k,y_call_pec_rlb256,y_call_pec_rlb1k,y_call_pec_ooo,0,y_call_pec_all]
    y_ret_pec = [y_ret_pec_no,y_ret_pec_1k,y_ret_pec_8k,y_ret_pec_rlb256,y_ret_pec_rlb1k,y_ret_pec_ooo,0,y_ret_pec_all]
    y_jalr_pec = [y_jalr_pec_no,y_jalr_pec_1k,y_jalr_pec_8k,y_jalr_pec_rlb256,y_jalr_pec_rlb1k,y_jalr_pec_ooo,0,y_jalr_pec_all]
    y_call_pec = [i*100 for i in y_call_pec]
    y_ret_pec= [i*100 for i in y_ret_pec]
    y_jalr_pec= [i*100 for i in y_jalr_pec]

    y_full_pec= [y_full_pec_no,y_full_pec_1k,y_full_pec_8k,y_full_pec_rlb256,y_full_pec_rlb1k,y_full_pec_ooo,0,y_full_pec_all]
    y_full_pec= [i*10000 for i in y_full_pec]

    print(y_pop)
    print(y_push)
    print(y_cfg_r)
    print(y_cfg_over)
    print(y_store_over)
    print(y_other)

    print(y_call_pec)
    print(y_ret_pec)
    print(y_jalr_pec)


    print(y_full_pec)

    bottom1 = (np.array(y_cfg_r) - np.array(y_cfg_over)).tolist()
    bottom2 = (np.array(bottom1) + np.array(y_other) - np.array(y_store_over)).tolist()
    bottom3 = np.sum([bottom2,y_push],axis=0).tolist()
    boo = np.array(y_call_pec) + np.array(y_ret_pec)
    boo = boo.tolist()

    print(bottom1)
    print(bottom2)
    print(bottom3)

    x_0 = [i-0.15-0.1 for i in x_widht]
    x_1 = [i for i in x_widht]
    x_2 = [i+0.2 for i in x_widht]
    y_0 = [0 for i in x_widht]

    l0 = ax.bar(x_0,y_other,width=0.3,color = 'white',ec='k',bottom = bottom1,lw=1.5)
    l1 = ax.bar(x_0,y_cfg_r,width=0.2, color = rgb_limit0[0],ec='k',lw=1.5)
    l2 = ax.bar(x_0,y_push,width=0.2, color = rgb_limit1[0],ec='k',bottom = bottom2,lw=1.5)
    l3 = ax.bar(x_0,y_pop,width=0.2, color = rgb_limit1[1],ec='k',bottom = bottom3,lw=1.5)

    l4 = ax.bar(x_1,y_call_pec,width=0.2, color = 'white',ec=rgb_limit1[1],lw=1.5)
    l5 = ax.bar(x_1,y_ret_pec,width=0.2, color = 'white', hatch = '/'*2,ec=rgb_limit1[1],bottom = y_call_pec,lw=1.5)
    l6 = ax.bar(x_1,y_jalr_pec,width=0.2, color = 'white', hatch = '\\'*2,ec=rgb_limit1[1],bottom = boo,lw=1.5)

    l7 = ax.bar(x_2,y_full_pec,width=0.2, color = 'white',ec='darkblue',lw=1.5)


    l66 = ax.bar(x_2,y_0,width=0.2, color = 'white')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    # x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(x_widht,opt_case_name,rotation=30,fontsize=17)
    ax.set_ylabel('CFI\nTime Cost Breakdown (%)',fontsize=15,color=rgb_limit1[1])
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    l11 = ax.legend((l0,l1,l2,l3),['Other Mon Inst.','Load CFG and Check','Push Stack','Pop Stack','','Call Mon. Time','Ret Mon. Time','Indirect Branch\n Mon. Time','','','','FIFO Full Time\n(* 100)'],
            loc='upper right',bbox_to_anchor=(0.297,1.68),ncol=1,fontsize=14)
    ax.add_artist(l11)
    l22 = ax.legend((l4,l5,l6),['Call Req.','Ret Req.','Indirect\nBranch Req.'],
            loc='upper right',bbox_to_anchor=(0.6,1.68),ncol=1,fontsize=14)
    ax.add_artist(l22)
    l22 = ax.legend((l66,l66,l66,l7),['','','','FIFO Full (* 100)'],
            loc='upper right',bbox_to_anchor=(1,1.68),ncol=1,fontsize=14)
    # ax.legend((None,h11),['FIFO Full Time','',''], loc='upper right',bbox_to_anchor=(0.6,1),ncol=2,fontsize=14)
    ax.grid(linestyle = ":")
    ax.tick_params(labelsize=15)
    ax.tick_params(axis='y',colors=rgb_limit1[1])

  
def draw_cfi(ax):
    x_widht = range(0,10)

    # fig = plt.figure(figsize=(10,3))  # 创建画布
    # ax = plt.gca()
    ax2 = ax.twinx()


    y_pop = get_line_de('mm_load_pec',7,2)[0][1:11]
    y_push = get_line_de('mm_store_pec',7,2)[0][1:11]
    y_cfg_r = get_line_de('mm_check_pec',7,2)[0][1:11]
    y_cfg_over = get_line_de('mm_check_over',7,2)[0][1:11]
    y_store_over = get_line_de('mm_store_over',7,2)[0][1:11]
    y_other = get_line_de('mm_other_pec',7,2)[0][1:11]
    y_over = get_line_de('overlap_pec',7,2)[0][1:11]

    y_call_pec = get_line_de('call_pec',7,2)[0][1:11]
    y_ret_pec = get_line_de('ret_pec',7,2)[0][1:11]
    y_jalr_pec = get_line_de('jalr_pec',7,2)[0][1:11]

    y_call_feq = get_line_de('call_ratio',7,2)[0][1:11]
    y_jalr_feq = get_line_de('jalr_ratio',7,2)[0][1:11]

    y_full_pec = get_line_de('full_pec',7,2)[0][1:11]

    y_pop = [i*100 for i in y_pop]
    y_push = [i*100 for i in y_push]
    y_cfg_r = [i*100 for i in y_cfg_r]
    y_cfg_over = [i*100 for i in y_cfg_over]
    y_store_over = [i*100 for i in y_store_over]
    y_other= [i*100 for i in y_other]
    y_over= [i*100 for i in y_over]

    y_call_pec = [i*100 for i in y_call_pec]
    y_ret_pec= [i*100 for i in y_ret_pec]
    y_jalr_pec= [i*100 for i in y_jalr_pec]

    y_call_feq = [i*10000 for i in y_call_feq]
    y_jalr_feq = [i*10000 for i in y_jalr_feq]

    y_full_pec= [i*10000 for i in y_full_pec]

    print(y_pop)
    print(y_push)
    print(y_cfg_r)
    print(y_cfg_over)
    print(y_store_over)
    print(y_other)

    print(y_call_pec)
    print(y_ret_pec)
    print(y_jalr_pec)

    print(y_call_feq)
    print(y_jalr_feq)

    print(y_full_pec)

    bottom1 = (np.array(y_cfg_r) - np.array(y_cfg_over)).tolist()
    bottom2 = (np.array(bottom1) + np.array(y_other) - np.array(y_store_over)).tolist()
    bottom3 = np.sum([bottom2,y_push],axis=0).tolist()
    boo = np.array(y_call_pec) + np.array(y_ret_pec)
    boo = boo.tolist()

    x_0 = [i-0.15-0.1 for i in x_widht]
    x_1 = [i for i in x_widht]
    x_2 = [i+0.2 for i in x_widht]
    y_0 = [0 for i in x_widht]

    l0 = ax.bar(x_0,y_other,width=0.3,color = 'white',ec='k',bottom = bottom1,lw=1.5)
    l1 = ax.bar(x_0,y_cfg_r,width=0.2, color = rgb_limit0[0],ec='k',lw=1.5)
    l2 = ax.bar(x_0,y_push,width=0.2, color = rgb_limit1[0],ec='k',bottom = bottom2,lw=1.5)
    l3 = ax.bar(x_0,y_pop,width=0.2, color = rgb_limit1[1],ec='k',bottom = bottom3,lw=1.5)

    l4 = ax.bar(x_1,y_call_pec,width=0.2, color = 'white',ec=rgb_limit1[1],lw=1.5)
    l5 = ax.bar(x_1,y_ret_pec,width=0.2, color = 'white', hatch = '/'*2,ec=rgb_limit1[1],bottom = y_call_pec,lw=1.5)
    l6 = ax.bar(x_1,y_jalr_pec,width=0.2, color = 'white', hatch = '\\'*2,ec=rgb_limit1[1],bottom = boo,lw=1.5)

    l7 = ax.bar(x_2,y_full_pec,width=0.2, color = 'white',ec='darkblue',lw=1.5)

    # ax2.plot(x_widht,y_0,lw=0)
    ax2.plot(x_widht,y_call_feq, color='black',marker='s',markersize=8,markerfacecolor='white',linestyle='-',lw=2)
    ax2.plot(x_widht,y_call_feq, color='black',marker='o',markersize=5,linestyle='--',lw=2)
    ax2.plot(x_widht,y_jalr_feq, color='black',marker='^',markersize=8,linestyle='--',lw=2)

    l66 = ax.bar(x_2,y_0,width=0.2, color = 'white')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    ax2.set_ylim(-2,62) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(range(0,10),x_name,rotation=0,fontsize=17)
    ax.set_ylabel('CFI\nTime Cost Breakdown (%)',fontsize=15,color=rgb_limit1[1])
    ax2.set_ylabel('Freq. (# / 10000 cycles)',fontsize=15)
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    l11 = ax.legend((l0,l1,l2,l3),['Other Mon. Inst.','Load CFG and Check','Push Stack','Pop Stack','','Call Mon. Time','Ret Mon. Time','Indirect Branch Mon. Time','','','','FIFO Full Time\n(* 100)'],
            loc='upper right',bbox_to_anchor=(0.3,1.65),ncol=1,fontsize=14)
    ax.add_artist(l11)
    l22 = ax.legend((l4,l5,l6),['Call Req.','Ret Req.','Indirect\nBranch Req.'],
            loc='upper right',bbox_to_anchor=(0.53,1.65),ncol=1,fontsize=14)
    ax.add_artist(l22)
    l33 = ax.legend((l66,l66,l66,l7),['','','','FIFO Full (* 100)'],
            loc='upper right',bbox_to_anchor=(0.8,1.65),ncol=1,fontsize=14)
    # ax.legend((None,h11),['FIFO Full Time','',''], loc='upper right',bbox_to_anchor=(0.6,1),ncol=2,fontsize=14)
    ax.grid(linestyle = ":")
    ax2.legend(['Call Req.','Ret Req.','Indirect\nBranch Req.'],loc='upper right',bbox_to_anchor=(1.02,1.65),ncol=1,fontsize=14)
    ax.tick_params(labelsize=15)
    ax.tick_params(axis='y',colors=rgb_limit1[1])
    ax2.tick_params(labelsize=15)

  
def draw_dfi_opt(ax):
    x_widht = range(0,len(opt_case))

    # fig = plt.figure(figsize=(10,3))  # 创建画布
    # ax = plt.gca()


    y_rdt_r_all = get_line_de('rdt_read_pec',7,4)[0][10]
    y_rdt_w_all = get_line_de('rdt_write_pec',7,4)[0][10]
    y_rds_r_all = get_line_de('rds_pec',7,4)[0][10]
    y_rds_over_all = get_line_de('rds_overlap',7,4)[0][10]
    y_rdt_over_all = get_line_de('rdt_overlap',7,4)[0][10]
    y_other_all = get_line_de('other_pec',7,4)[0][10]
    y_over_all = get_line_de('overlap_pec',7,4)[0][10]

    y_load_pec_all = get_line_de('load_pec',7,4)[0][10]
    y_store_pec_all = get_line_de('store_pec',7,4)[0][10]
    y_lib_pec_all = get_line_de('lib_pec',7,4)[0][10]
    y_full_pec_all = get_line_de('full_pec',7,4)[0][10]

    y_rdt_r_no = get_line_de('rdt_read_pec',0,4)[0][10]
    y_rdt_w_no = get_line_de('rdt_write_pec',0,4)[0][10]
    y_rds_r_no = get_line_de('rds_pec',0,4)[0][10]
    y_rds_over_no = get_line_de('rds_overlap',0,4)[0][10]
    y_rdt_over_no = get_line_de('rdt_overlap',0,4)[0][10]
    y_other_no = get_line_de('other_pec',0,4)[0][10]
    y_over_no = get_line_de('overlap_pec',0,4)[0][10]

    y_load_pec_no = get_line_de('load_pec',0,4)[0][10]
    y_store_pec_no = get_line_de('store_pec',0,4)[0][10]
    y_lib_pec_no = get_line_de('lib_pec',0,4)[0][10]
    y_full_pec_no = get_line_de('full_pec',0,4)[0][10]

    y_rdt_r_1k = get_line_de('rdt_read_pec',2,4)[0][10]
    y_rdt_w_1k = get_line_de('rdt_write_pec',2,4)[0][10]
    y_rds_r_1k = get_line_de('rds_pec',2,4)[0][10]
    y_rds_over_1k = get_line_de('rds_overlap',2,4)[0][10]
    y_rdt_over_1k = get_line_de('rdt_overlap',2,4)[0][10]
    y_other_1k = get_line_de('other_pec',2,4)[0][10]
    y_over_1k = get_line_de('overlap_pec',2,4)[0][10]

    y_load_pec_1k = get_line_de('load_pec',2,4)[0][10]
    y_store_pec_1k = get_line_de('store_pec',2,4)[0][10]
    y_lib_pec_1k = get_line_de('lib_pec',2,4)[0][10]
    y_full_pec_1k = get_line_de('full_pec',2,4)[0][10]

    y_rdt_r_8k = get_line_de('rdt_read_pec',1,4)[0][10]
    y_rdt_w_8k = get_line_de('rdt_write_pec',1,4)[0][10]
    y_rds_r_8k = get_line_de('rds_pec',1,4)[0][10]
    y_rds_over_8k = get_line_de('rds_overlap',1,4)[0][10]
    y_rdt_over_8k = get_line_de('rdt_overlap',1,4)[0][10]
    y_other_8k = get_line_de('other_pec',1,4)[0][10]
    y_over_8k = get_line_de('overlap_pec',1,4)[0][10]

    y_load_pec_8k = get_line_de('load_pec',1,4)[0][10]
    y_store_pec_8k = get_line_de('store_pec',1,4)[0][10]
    y_lib_pec_8k = get_line_de('lib_pec',1,4)[0][10]
    y_full_pec_8k = get_line_de('full_pec',1,4)[0][10]

    y_rdt_r_rlb256 = get_line_de('rdt_read_pec',4,4)[0][10]
    y_rdt_w_rlb256 = get_line_de('rdt_write_pec',4,4)[0][10]
    y_rds_r_rlb256 = get_line_de('rds_pec',4,4)[0][10]
    y_rds_over_rlb256 = get_line_de('rds_overlap',4,4)[0][10]
    y_rdt_over_rlb256 = get_line_de('rdt_overlap',4,4)[0][10]
    y_other_rlb256 = get_line_de('other_pec',4,4)[0][10]
    y_over_rlb256 = get_line_de('overlap_pec',4,4)[0][10]

    y_load_pec_rlb256 = get_line_de('load_pec',4,4)[0][10]
    y_store_pec_rlb256 = get_line_de('store_pec',4,4)[0][10]
    y_lib_pec_rlb256 = get_line_de('lib_pec',4,4)[0][10]
    y_full_pec_rlb256 = get_line_de('full_pec',4,4)[0][10]

    y_rdt_r_rlb1k= get_line_de('rdt_read_pec',3,4)[0][10]
    y_rdt_w_rlb1k= get_line_de('rdt_write_pec',3,4)[0][10]
    y_rds_r_rlb1k = get_line_de('rds_pec',3,4)[0][10]
    y_rds_over_rlb1k = get_line_de('rds_overlap',3,4)[0][10]
    y_rdt_over_rlb1k = get_line_de('rdt_overlap',3,4)[0][10]
    y_other_rlb1k = get_line_de('other_pec',3,4)[0][10]
    y_over_rlb1k = get_line_de('overlap_pec',3,4)[0][10]

    y_load_pec_rlb1k = get_line_de('load_pec',3,4)[0][10]
    y_store_pec_rlb1k = get_line_de('store_pec',3,4)[0][10]
    y_lib_pec_rlb1k = get_line_de('lib_pec',3,4)[0][10]
    y_full_pec_rlb1k = get_line_de('full_pec',3,4)[0][10]

    y_rdt_r_ooo = get_line_de('rdt_read_pec',5,4)[0][10]
    y_rdt_w_ooo = get_line_de('rdt_write_pec',5,4)[0][10]
    y_rds_r_ooo = get_line_de('rds_pec',5,4)[0][10]
    y_rds_over_ooo = get_line_de('rds_overlap',5,4)[0][10]
    y_rdt_over_ooo = get_line_de('rdt_overlap',5,4)[0][10]
    y_other_ooo = get_line_de('other_pec',5,4)[0][10]
    y_over_ooo = get_line_de('overlap_pec',5,4)[0][10]

    y_load_pec_ooo= get_line_de('load_pec',5,4)[0][10]
    y_store_pec_ooo= get_line_de('store_pec',5,4)[0][10]
    y_lib_pec_ooo= get_line_de('lib_pec',5,4)[0][10]
    y_full_pec_ooo = get_line_de('full_pec',5,4)[0][10]

    y_rdt_r_par = get_line_de('rdt_read_pec',6,4)[0][10]
    y_rdt_w_par= get_line_de('rdt_write_pec',6,4)[0][10]
    y_rds_r_par= get_line_de('rds_pec',6,4)[0][10]
    y_rds_over_par = get_line_de('rds_overlap',6,4)[0][10]
    y_rdt_over_par = get_line_de('rdt_overlap',6,4)[0][10]
    y_other_par = get_line_de('other_pec',6,4)[0][10]
    y_over_par = get_line_de('overlap_pec',6,4)[0][10]

    y_load_pec_par = get_line_de('load_pec',6,4)[0][10]
    y_store_pec_par = get_line_de('store_pec',6,4)[0][10]
    y_lib_pec_par = get_line_de('lib_pec',6,4)[0][10]
    y_full_pec_par = get_line_de('full_pec',6,4)[0][10]


    y_rdt_r = [y_rdt_r_no,y_rdt_r_1k,y_rdt_r_8k,y_rdt_r_rlb256,y_rdt_r_rlb1k,y_rdt_r_ooo,y_rdt_r_par,y_rdt_r_all]
    y_rdt_r = [i*100 for i in y_rdt_r]
    y_rdt_w = [y_rdt_w_no,y_rdt_w_1k,y_rdt_w_8k,y_rdt_w_rlb256,y_rdt_w_rlb1k,y_rdt_w_ooo,y_rdt_w_par,y_rdt_w_all]
    y_rdt_w = [i*100 for i in y_rdt_w]
    y_rds_r = [y_rds_r_no,y_rds_r_1k,y_rds_r_8k,y_rds_r_rlb256,y_rds_r_rlb1k,y_rds_r_ooo,y_rds_r_par,y_rds_r_all]
    y_rds_r = [i*100 for i in y_rds_r]
    y_rds_over = [y_rds_over_no,y_rds_over_1k,y_rds_over_8k,y_rds_over_rlb256,y_rds_over_rlb1k,y_rds_over_ooo,y_rds_over_par,y_rds_over_all]
    y_rds_over = [i*100 for i in y_rds_over]
    y_rdt_over = [y_rdt_over_no,y_rdt_over_1k,y_rdt_over_8k,y_rdt_over_rlb256,y_rdt_over_rlb1k,y_rdt_over_ooo,y_rdt_over_par,y_rdt_over_all]
    y_rdt_over = [i*100 for i in y_rdt_over]
    y_other = [y_other_no,y_other_1k,y_other_8k,y_other_rlb256,y_other_rlb1k,y_other_ooo,y_other_par,y_other_all]
    y_other= [i*100 for i in y_other]
    y_over = [y_over_no,y_over_1k,y_over_8k,y_over_rlb256,y_over_rlb1k,y_over_ooo,y_over_par,y_over_all]
    y_over = [i*100 for i in y_over]

    y_load_pec = [y_load_pec_no,y_load_pec_1k,y_load_pec_8k,y_load_pec_rlb256,y_load_pec_rlb1k,y_load_pec_ooo,y_load_pec_par,y_load_pec_all]
    y_load_pec = [i*100 for i in y_load_pec]
    y_store_pec = [y_store_pec_no,y_store_pec_1k,y_store_pec_8k,y_store_pec_rlb256,y_store_pec_rlb1k,y_store_pec_ooo,y_store_pec_par,y_store_pec_all]
    y_store_pec= [i*100 for i in y_store_pec]
    y_lib_pec = [y_lib_pec_no,y_lib_pec_1k,y_lib_pec_8k,y_lib_pec_rlb256,y_lib_pec_rlb1k,y_lib_pec_ooo,y_lib_pec_par,y_lib_pec_all]
    y_lib_pec= [i*100 for i in y_lib_pec]


    y_full_pec = [y_full_pec_no,y_full_pec_1k,y_full_pec_8k,y_full_pec_rlb256,y_full_pec_rlb1k,y_full_pec_ooo,y_full_pec_par,y_full_pec_all]
    y_full_pec= [i*100 for i in y_full_pec]

    print(y_rdt_r)
    print(y_rdt_w)
    print(y_rds_r)
    print(y_rds_over)
    print(y_rdt_over)
    print(y_other)

    print(y_load_pec)
    print(y_store_pec)
    print(y_lib_pec)

    print(y_full_pec)

    bottom1 = (np.array(y_rds_r) - np.array(y_rds_over)).tolist()
    bottom2 = (np.array(bottom1) + np.array(y_other) - np.array(y_rdt_over)).tolist()
    bottom3 = np.sum([bottom2,y_rdt_w],axis=0).tolist()
    boo = np.array(y_load_pec) + np.array(y_store_pec)
    boo = boo.tolist()

    x_0 = [i-0.15-0.1 for i in x_widht]
    x_1 = [i for i in x_widht]
    x_2 = [i+0.2 for i in x_widht]
    y_0 = [0 for i in x_widht]

    l0 = ax.bar(x_0,y_other,width=0.3,color = 'white',ec='k',bottom = bottom1,lw=1.5)
    l1 = ax.bar(x_0,y_rds_r,width=0.2, color = rgb_limit0[0],ec='k',lw=1.5)
    l2 = ax.bar(x_0,y_rdt_w,width=0.2, color = rgb_limit1[0],ec='k',bottom = bottom2,lw=1.5)
    l3 = ax.bar(x_0,y_rdt_r,width=0.2, color = rgb_limit1[1],ec='k',bottom = bottom3,lw=1.5)

    l4 = ax.bar(x_1,y_load_pec,width=0.2, color = 'white',ec=rgb_limit1[1],lw=1.5)
    l5 = ax.bar(x_1,y_store_pec,width=0.2, color = 'white', hatch = '/'*2,ec=rgb_limit1[1],bottom = y_load_pec,lw=1.5)
    l6 = ax.bar(x_1,y_lib_pec,width=0.2, color = 'white', hatch = '\\'*2,ec=rgb_limit1[1],bottom = boo,lw=1.5)

    l7 = ax.bar(x_2,y_full_pec,width=0.2, color = 'white',ec='darkblue',lw=1.5)

    # ax2.plot(x_widht,y_load_feq, color='black',marker='s',markersize=8,markerfacecolor='white',linestyle='-',lw=2)
    # ax2.plot(x_widht,y_store_feq, color='black',marker='o',markersize=8,linestyle='--',lw=2)
    # ax2.plot(x_widht,y_lib_feq, color='black',marker='^',markersize=10,markerfacecolor='white',linestyle=':',lw=2)

    l66 = ax.bar(x_2,y_0,width=0.2, color = 'white')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    # ax2.set_ylim(-2,66) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    # x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(range(0,len(opt_case_name)),opt_case_name,rotation=30,fontsize=17)
    ax.set_ylabel('DFI\nTime Cost Breackdown (%)',fontsize=15,color=rgb_limit1[1])
    # ax2.set_ylabel('Freq. (# / 1000 cycles)',fontsize=15)
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    l11 = ax.legend((l0,l1,l2,l3),['Other Mon. Inst.','Load RDS and Check','Update RDT','Load RDT','','Load Mon. Time','Store Mon. Time','Lib Mon. Time','','','','FIFO Full Time'],
            loc='upper right',bbox_to_anchor=(0.3,1.7),ncol=1,fontsize=14)
    ax.add_artist(l11)
    l22 = ax.legend((l66,l4,l5,l6),['','Load Req.','Store Req.','Lib Req.'],
            loc='upper right',bbox_to_anchor=(0.6,1.7),ncol=1,fontsize=14)
    ax.add_artist(l22)
    l22 = ax.legend((l66,l66,l66,l7),['','','','FIFO Full'],
            loc='upper right',bbox_to_anchor=(1,1.7),ncol=1,fontsize=14)
    # ax.legend((None,h11),['FIFO Full Time','',''], loc='upper right',bbox_to_anchor=(0.6,1),ncol=2,fontsize=14)
    ax.grid(linestyle = ":")
    # ax2.legend(['Load Freq.','Store Freq.','Lib Freq.'],loc='upper right',bbox_to_anchor=(1.1,1.48),ncol=1,fontsize=14)
    ax.tick_params(labelsize=15)
    ax.tick_params(axis='y',colors=rgb_limit1[1])
    # ax2.tick_params(labelsize=15)

  
    # plt.savefig('dfi_res_opt.pdf',dpi=300, bbox_inches='tight')
    # plt.show()


def draw_cachehit():
    x_widht = range(0,10)

    fig = plt.figure(figsize=(10,1.5))  # 创建画布
    ax = plt.gca()


    y_cfi = get_line_de('cachehitrate',7,2)[0][1:11]
    y_dfi = get_line_de('cachehitrate',7,4)[0][1:11]
    y_sstack = get_line_de('cachehitrate',7,0)[0][1:11]
    y_hdfi = get_line_de('cachehitrate',7,3)[0][1:11]

    y_cfi = [i*100 for i in y_cfi]
    y_dfi = [i*100 for i in y_dfi]
    y_sstack = [i*100 for i in y_sstack]
    y_hdfi = [i*100 for i in y_hdfi]

    print(y_cfi)
    print(y_dfi)
    print(y_sstack)
    print(y_hdfi)

    x_0 = [i-0.3 for i in x_widht]
    x_1 = [i-0.1 for i in x_widht]
    x_2 = [i+0.1 for i in x_widht]
    x_3 = [i+0.3 for i in x_widht]

    ax.bar(x_0,y_sstack,width=0.2,color = rgb_limit0[0],ec='k')
    ax.bar(x_1,y_cfi,width=0.2, color = rgb_limit0[1],ec='k')
    ax.bar(x_2,y_hdfi,width=0.2, color = rgb_limit1[0],ec='k')
    ax.bar(x_3,y_dfi,width=0.2,color = rgb_limit1[1],ec='k')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(0,100) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(range(0,10),x_name,rotation=0,fontsize=17)
    ax.set_ylabel('Hit Rate (%)',fontsize=15)
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    ax.legend(['Shadow Stack','CFI','LW-DIFT','DFI'],loc='upper center',bbox_to_anchor=(0.5,1.4),ncol=4,fontsize=14)
    plt.grid(linestyle = ":")
    ax.tick_params(labelsize=15)
    ax.yaxis.set_major_locator(MultipleLocator(25))

  
    plt.savefig('cache_hit.pdf',dpi=300, bbox_inches='tight')
    plt.show()

def draw_rlbhit():
    x_widht = range(0,10)

    fig = plt.figure(figsize=(10,1.5))  # 创建画布
    ax = plt.gca()


    y_cfi = get_line_de('rlb_hit',4,2)[0][1:11]
    y_dfi = get_line_de('rlb_hit',4,4)[0][1:11]
    y_cfi_64 = get_line_de('rlb_hit',3,2)[0][1:11]
    y_dfi_64= get_line_de('rlb_hit',3,4)[0][1:11]

    y_cfi = [i*100 for i in y_cfi]
    y_dfi = [i*100 for i in y_dfi]
    y_cfi_64 = [i*100 for i in y_cfi_64]
    y_dfi_64 = [i*100 for i in y_dfi_64]

    print(y_cfi)
    print(y_dfi)
    print(y_cfi_64)
    print(y_dfi_64)

    x_0 = [i-0.3 for i in x_widht]
    x_1 = [i-0.1 for i in x_widht]
    x_2 = [i-0.15 for i in x_widht]
    x_3 = [i+0.15 for i in x_widht]

    # ax.bar(x_0,y_cfi,width=0.2,color = 'azure',ec='k')
    # ax.bar(x_1,y_dfi,width=0.2, color = 'teal',ec='k')
    ax.bar(x_2,y_dfi,width=0.3, color = rgb_limit0[0],ec='k')
    ax.bar(x_3,y_dfi_64,width=0.3,color = rgb_limit0[1],ec='k')

    ax.set_xlim(-0.5,len(x_widht)-0.5)
    ax.set_ylim(60,100) 
    ax.xaxis.set_major_locator(MultipleLocator(1))
    x_name = ['401','429','433','445','456','458','462','470','473','Avg.']
    ax.set_xticks(range(0,10),x_name,rotation=0,fontsize=17)
    ax.set_ylabel('Hit Rate (%)',fontsize=15)
    ax.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['top'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.5);###设置底部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.5);###设置底部坐标轴的粗细

    ax.legend(['RLB_256B','RLB_1KB'],loc='upper center',bbox_to_anchor=(0.5,1.43),ncol=4,fontsize=14)
    plt.grid(linestyle = ":")
    ax.tick_params(labelsize=15)

  
    plt.savefig('rlb_hit.pdf',dpi=300, bbox_inches='tight')
    plt.show()


def draw_res_all():
    fig,axs = plt.subplots(4,1,figsize=(10,21),dpi=55,sharex='col',constrained_layout=True)

    draw_shadow_stack(axs[0])
    draw_cfi(axs[1])
    draw_lw_dift(axs[2])
    draw_dfi(axs[3])

    # fig.tight_layout(h_pad=-2)
    plt.subplots_adjust(left=None,bottom=None,right=None,top=None,wspace=0.15,hspace=0.1)
    # plt.savefig('all.pdf',dpi=300, bbox_inches='tight')
    plt.show()

def draw_res_allopt():
    fig,axs = plt.subplots(4,1,figsize=(10,21),dpi=55,sharex='col',constrained_layout=True)

    draw_shadow_stack_opt(axs[0])
    draw_cfi_opt(axs[1])
    draw_lw_diftopt(axs[2])
    draw_dfi_opt(axs[3])

    # fig.tight_layout(h_pad=-1)
    # plt.savefig('all.pdf',dpi=300, bbox_inches='tight')
    plt.show()


p =[]
for i in range(1,len(sys.argv)): 
    p.append(i)
case = ''
for i in p:
    if sys.argv[i] == '-latency':
        case = 'latency'
    if sys.argv[i] == '-overhead':       
        case = 'overhead'
    if sys.argv[i] == '-ss':       
        case = 'ss'
    if sys.argv[i] == '-ssopt':       
        case = 'ssopt'
    if sys.argv[i] == '-wh':       
        case = 'wh'
    if sys.argv[i] == '-cfi':       
        case = 'cfi'
    if sys.argv[i] == '-cfiopt':       
        case = 'cfiopt'
    if sys.argv[i] == '-hdfi':       
        case = 'hdfi'
    if sys.argv[i] == '-dfi':       
        case = 'dfi'
    if sys.argv[i] == '-dfiopt':       
        case = 'dfiopt'
    if sys.argv[i] == '-lw':       
        case = 'lw'
    if sys.argv[i] == '-lwopt':       
        case = 'lwopt'
    if sys.argv[i] == '-dfi_cost':       
        case = 'dfi_cost'
    if sys.argv[i] == '-cache_hit':       
        case = 'cache_hit'
    if sys.argv[i] == '-rlb_hit':       
        case = 'rlb_hit'
    if sys.argv[i] == '-all':       
        case = 'all'
    if sys.argv[i] == '-allopt':       
        case = 'allopt'


if case == 'latency':
    draw_latency()
if case == 'overhead':
    draw_overhead()
if case == 'ss':
    draw_shadow_stack()
if case == 'ssopt':
    draw_shadow_stack_opt()
if case == 'wh':
    draw_wh_insight()
if case == 'cfi':
    draw_cfi()
if case == 'cfiopt':
    draw_cfi_opt()
if case == 'hdfi':
    draw_hdfi_insight()
if case == 'dfi':
    draw_dfi()
if case == 'dfiopt':
    draw_dfi_opt()
if case == 'lw':
    draw_lw_dift()
if case == 'lwopt':
    draw_lw_diftopt()
if case == 'cache_hit':
    draw_cachehit()
if case == 'rlb_hit':
    draw_rlbhit()
if case == 'all':
    draw_res_all()
if case == 'allopt':
    draw_res_allopt()
